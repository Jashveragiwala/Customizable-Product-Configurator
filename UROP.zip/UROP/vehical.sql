-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 22, 2022 at 08:30 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `urop`
--

-- --------------------------------------------------------

--
-- Table structure for table `vehical`
--

DROP TABLE IF EXISTS `vehical`;
CREATE TABLE IF NOT EXISTS `vehical` (
  `name` text NOT NULL,
  `minpax` int(100) NOT NULL,
  `maxpax` int(100) NOT NULL,
  `operation` text NOT NULL,
  `terrain` text NOT NULL,
  `cabin` text NOT NULL,
  `image` varchar(200) NOT NULL,
  `button` varchar(200) NOT NULL,
  `image2` varchar(200) DEFAULT NULL,
  `image3` varchar(200) DEFAULT NULL,
  `hardpoints` int(3) DEFAULT NULL,
  `weight` int(100) DEFAULT NULL,
  `cost` int(7) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehical`
--

INSERT INTO `vehical` (`name`, `minpax`, `maxpax`, `operation`, `terrain`, `cabin`, `image`, `button`, `image2`, `image3`, `hardpoints`, `weight`, `cost`) VALUES
('Baseline1', 2, 6, 'Mobile', 'Urban', 'Non-expandable', 'images/model1.jpg', 'features.php', 'images/model11.jpg', NULL, 6, 400, 225000),
('Baseline2', 2, 6, 'Mobile', 'Rural', 'Non-expandable', 'images/model1.jpg', 'features2.php', 'images/model11.jpg', NULL, 6, 450, 275000),
('Baseline3', 2, 6, 'Static', 'Urban', 'Non-expandable', 'images/model1.jpg', 'features3.php', 'images/model11.jpg', NULL, 6, 500, 200000),
('Baseline4', 2, 6, 'Static', 'Urban', 'Expandable', 'images/model1.jpg', 'features4.php', 'images/model11.jpg', NULL, 6, 550, 300000),
('Baseline5', 2, 6, 'Static', 'Rural', 'Non-expandable', 'images/model1.jpg', 'features5.php', 'images/model11.jpg', NULL, 6, 450, 250000),
('Baseline6', 6, 12, 'Mobile', 'Urban', 'Non-expandable', 'images/model3.jpg', 'features6.php', 'images/model31.jpg', NULL, 9, 2000, 475000),
('Baseline7', 6, 12, 'Mobile', 'Rural', 'Non-expandable', 'images/model2.jpg', 'features7.php', 'images/model21.jpg', 'images/model22.jpg', 9, 1500, 525000),
('Baseline8', 6, 12, 'Static', 'Urban', 'Non-expandable', 'images/model3.jpg', 'features8.php', 'images/model31.jpg', NULL, 9, 2000, 450000),
('Baseline9', 6, 12, 'Static', 'Urban', 'Expandable', 'images/model4.jpg', 'features9.php', 'images/model41.jpg', 'images/model42.jpg', 9, 3000, 600000),
('Baseline10', 6, 12, 'Static', 'Rural', 'Non-expandable', 'images/model2.jpg', 'features10.php', 'images/model21.jpg', 'images/model22.jpg', 9, 1500, 500000),
('Baseline11', 10, 20, 'Static', 'Urban', 'Non-expandable', 'images/model3.jpg', 'features11.php', 'images/model31.jpg', NULL, 12, 4000, 800000),
('Baseline12', 10, 20, 'Static', 'Urban', 'Expandable', 'images/model4.jpg', 'features12.php', 'images/model41.jpg', 'images/model42.jpg', 12, 5000, 1000000),
('Baseline13', 10, 20, 'Static', 'Rural', 'Non-expandable', 'images/model2.jpg', 'features13.php', 'images/model21.jpg', 'images/model22.jpg', 12, 3000, 850000);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
