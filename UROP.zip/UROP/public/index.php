<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="with=device-width,
	initial-scale=1.0">
	<title> ST Engineering </title>
	<link rel="stylesheet" href="style.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
	<?php 
	include('header.php'); // imports the code from header.php  
	?>
	<section class="configurator">
		<br>
		<h1 class="up" style="font-size: 50px; margin-left: 102px;">  command and communications vehicle Configurator </h1>
		<h1 class="down" style="font-size: 24px; margin-left: 105px;"> Use the configurator to configure your very own ideal vehicle. </h1>
		<br>
	</section>

	<section class = "header">

	<div class="text-box">
		<br><br><br><br><br><br><br><br><br><br><br><br><br>
		<h1 class="up"> Start new configuration of your ideal Vehicle</h1>
		<br><br>
		<a href="model.php" class="hero-btn"> Start configuration </a>  <!-- clickable button to go to model.php page-->
	</div>
	</section>



	