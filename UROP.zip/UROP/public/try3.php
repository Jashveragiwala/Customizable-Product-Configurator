<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="with=device-width,
  initial-scale=1.0">
  <title> ST Engineering </title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="style.css">
</head>

<body style="background:   url(images/ema.jpg);
      min-height: 600px;  
      width: 100%;
      background-position: center;
      background-size: cover;
      position: relative;
      text-align: center;
      color:  #FF0000; 
      font-size: 15px;">

    <?php  
    include("db.php"); // connect database
    session_start(); // use to get php variables from summary page to try3.php page 
    ?>
   <!-- similar to header.php -->
   <section class="homepage-nav-bar">
    <br>
    <nav> 
      <div class="nav-links logo-wrapper" id="navLinks">
        <ul>
          <li> <h1> Truck configurator </h1> </li>
          <li> <a href="https://www.stengg.com/"><img src="images/logo.jpg" width=100px align="right"></a></li>
        </ul>
      </div>
    </nav>
    <hr align="center"; width = 100% >
  </section>

  <section style="text-align: left;">
    <nav> 
      <div class="nav-links" id="navLinks">
        <ul>
          <li><a href="index.php">Start</a></li> 
          <li><a href="model.php">Model</a></li> 
          <li><a href=<?php echo $_REQUEST["post22"];?>>Features</a></li>
          <li><a href=<?php echo $_REQUEST["post23"];?>>Summary</a></li>
        </ul>
      </div>
    </nav>
  </section>

  <section >
    <br><br><br><br><br><br><br><br>
    <h1 style="color: #000000; font-size: 40px; margin-left: 7%; margin-right:7%; text-align: center;"> Thank You For Choosing Us<br> Please press Send for Quotation to send us a request of your desired model. </h1> *Accept and give permission to send us an email and after checking the credentials, send us an email. <br> <br>

    <!-- following php commands changes the varialbes that are passed from summary page and they have been added usnits like KW etc -->
    <?php 
    if($_REQUEST["opt1"] == "Option"){
      $opt1 = "Option Not Selected";
    }
    else{
      $opt1 = $_REQUEST["opt1"] . " KW";
    }

    if($_REQUEST["opt2"] == "Option"){
      $opt2 = "Option Not Selected";
    }
    else{
      $opt2 = $_REQUEST["opt2"] . " KW";
    }

    if($_REQUEST["opt3"] == "Option"){
      $opt3 = "Option Not Selected";
    }
    else{
      $opt3 = $_REQUEST["opt3"] . " KW";
    }

    if($_REQUEST["opt4"] == "None"){
      $opt4 = "None";
    }
    else{
      $opt4 = "Generator ".$_REQUEST["opt4"];
      $opt2 = $opt1;
    }

    if($_REQUEST["opt6"] == "Option"){
      $opt6 = "Option Not Selected";
    }
    else{
      $opt6 = $_REQUEST["opt6"] . " KW";
    }

    if($_REQUEST["opt7"] == "Option"){
      $opt7 = "Option Not Selected";
    }
    else{
      $opt7 = $_REQUEST["opt7"] . " KW";
    }

    if($_REQUEST["opt8"] == "Option"){
      $opt8 = "Option Not Selected";
    }
    else{
      $opt8 = $_REQUEST["opt8"] . " CFM";
    }
    if($_REQUEST["opt11"] == "Option"){
      $opt11 = "Option Not Selected";
    }
    else{
      $opt11 = $_REQUEST["opt11"];
    }

    if($_REQUEST["opt12"] == "Option"){
      $opt12 = "Option Not Selected";
    }
    else{
      $opt12 = $_REQUEST["opt12"] . " M";
    }

    if($_REQUEST["opt19"] == 'Option'){
      $opt19 = "Option Not Selected";
    }
    else{
      $opt19 = $_REQUEST["opt19"]. " Module";
    }

    if($_REQUEST["opt20"] == 'Option'){
      $opt20 = "Option Not Selected";
    }
    else{
      $opt20 = $_REQUEST["opt20"]. " Module";
    }

    if($_REQUEST["opt21"] == 'Option'){
      $opt21 = "Option Not Selected";
    }
    else{
      $opt21 = $_REQUEST["opt21"]." Module";
    }
    ?>
     
    <!-- the below command is to make a form with just a button so once the button is pressed then an email is generated which will be sent to jashverg@gmail.com to place an order for the truch with sepcifications selected. -->
    <!-- please change the mailto: the emailid to a different one to recieve emails -->
    <form action='mailto:jashverg@gmail.com?
                 &subject=Please send the Quotation for the selected Truck model 
                 &body=Dear Sir/Madam, %0D%0A%0D%0AClient Name: <?php echo $_REQUEST["name"];?> %0D%0AClient Email ID : <?php echo $_REQUEST["email"];?>%0D%0AClient Phone Number : <?php echo $_REQUEST["number"];?>%0D%0A%0D%0AThe sepcifications of the desired truck are as follows: %0D%0A%0D%0AModel : <?php echo $_REQUEST["post"];?>%0D%0A%0D%0APower System Capacity :- %0D%0A%0D%0AGenerator 1 Capacity : <?php echo $opt1;?>%0D%0AGenerator 2 Capacity : <?php echo $opt2;?>%0D%0ABattery System / UPS Capacity : <?php echo $opt3;?>%0D%0AGenerator Redundancy/Synchronization : <?php echo $opt4;?>%0D%0A%0D%0AHVAC System :- %0D%0A%0D%0AAir-conditioning System 1 Capacity : <?php echo $opt6;?>%0D%0AAir-conditioning System 2 Capacity : <?php echo $opt7;?>%0D%0AVentilation System Capacity : <?php echo $opt8;?>%0D%0AAir-conditioning System Redundancy : <?php echo $_REQUEST["opt9"];?>%0D%0AVentilation System Redundancy : <?php echo $_REQUEST["opt10"];?>%0D%0A%0D%0AUtility Features and Functionalities :- %0D%0A%0D%0ATelescopic Mast System Quantity : <?php echo $opt11;?>%0D%0ATelescopic Mast System Height : <?php echo $opt12;?>%0D%0AUtilities and Infrastructure Monitoring and Control : <?php echo $_REQUEST["opt13"];?>%0D%0ABlinker Lights Availability : <?php echo $_REQUEST["opt14"];?>%0D%0AWork Light Availability : <?php echo $_REQUEST["opt15"];?>%0D%0A%0D%0AOnboard Systems Features and Functionalities :- %0D%0A%0D%0AVisualization System Availability : <?php echo $_REQUEST["opt16"];?>%0D%0ASurveillance System Availability : <?php echo $_REQUEST["opt17"];?>%0D%0ACommunications Network System Availability : <?php echo $_REQUEST["opt18"];?>%0D%0A%0D%0AFurniture :- %0D%0A%0D%0AConsole Availability : <?php echo $opt19;?>%0D%0A19 Equipment Rack Availability : <?php echo $opt20;?>%0D%0AStorage Space Availability : <?php echo $opt21;?>%0D%0A%0D%0ARegards,%0D%0A<?php echo $_REQUEST["name"];?>.' method="POST"> 
<input type="Submit" value="Send for Quotation" style="font-size: 25px; padding-left: 5px; padding-top: 5px; padding-right: 5px; padding-bottom: 5px; border-radius: 5px; "></input>
</form>

  </section>
</body>
</html>
