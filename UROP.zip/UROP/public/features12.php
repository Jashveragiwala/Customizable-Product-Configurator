<!DOCTYPE html>
<html>
<head>
   <meta name="viewport" content="with=device-width,
   initial-scale=1.0">
   <title> ST Engineering </title>
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
   <link rel="stylesheet" href="style.css">

   <style>
   *{
     margin: 0;
     padding: 0;
     font-family: 'Bebas Neue', cursive;
   }
   
   .collapsible {
     background-color: #777;
     color: white;
     cursor: pointer;
     padding: 18px;
     width: 80%;
     border: none;
     text-align: left;
     outline: none;
     font-size: 15px;
     margin-left: 100px;
   }

   .active, .collapsible:hover {
     background-color: #555;
   }

   .collapsible:after {
     content: '\002B';
     color: white;
     font-weight: bold;
     float: right;
     margin-left: 5px;
   }

   .active:after {
     content: "\2212";
   }

   .content {
     padding: 0 18px;
     max-height: 0;
     overflow: hidden;
     transition: max-height 0.2s ease-out;
     background-color: #EBECF0;
     margin-left: 100px;
     width: 76.8%;
   }

   .content select {
      width: 40%;
      font-size: 20px;
   }
   .dropdown h1{
      font-size: 25px;
      color: #000000;
   }

   .dropdown input[type="button"]{
      font-size: 22px;
      margin-left: 8.8%;     
   }

   .footer button{
       margin-left: 9%;
       width: 14%;
       height: 100%;
       text-align: center;
       font-family:'Bebas Neue', cursive;
       border-radius: 10px;
       background-color: #EBECF0 ;
       padding-top: 5px;
       padding-bottom: 5px;
   }
   .footer button h1{
      font-size: 25px;
   }
   .footer input{
      font-size: 25px;
      width: 18%;
      height: 100%;
      text-align: center;
      font-family:'Bebas Neue', cursive;
      border-radius: 10px;
      background-color: #EBECF0 ;
      padding-top: 5px;
      padding-bottom: 5px;
   }

   .swiper {
      width: 335px;
      height: 220px;
    }

  .swiper-slide img{
      width: 100%;
      height: 190px;
    }

  .swiper-pagination{
      background: rgb(255,255,255,0.64);
      bottom: 0px;  
    }
   .overlay_flight_traveldil {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, 0.7);
  transition: opacity 500ms;
  visibility: hidden;
  opacity: 0;
}
.overlay_flight_traveldil:target {
  visibility: visible;
  opacity: 1;
}
.popup_flight_travlDil {
  margin: 70px auto;
  padding: 20px;
  background: #888;
  border-radius: 5px;
  width: 30%;
  position: relative;
  transition: all 2s ease-in-out;
}
.popup_flight_travlDil .close_flight_travelDl {
  position: absolute;
  top: 20px;
  right: 30px;
  transition: all 200ms;
  font-size: 30px;
  font-weight: bold;
  text-decoration: none;
  color: #333;
}
.popup_flight_travlDil .content_flightht_travel_dil {
  max-height: 30%;
  overflow: auto;
}
   </style>
</head>
<body>

   <?php 
   include('header2.php'); 
   include('db.php');
   ?>

   <section class="configurator">
      <br>     
      <br>
      <h1 class="up"> &nbsp;&nbsp;&nbsp;SELECT YOUR PREFERRED FEATURES </h1>
      <h1 class="down"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Design your very own ideal truck </h1>
      <br>
      <br>
      <hr width=100%> 
   </section>
   <section class="dropdown">
       <form method="POST" action="summary12.php" id="aForm">
       <div style="width: 100%; display: table;" class="choose">
           <div style="display: table-row;">
               <div style="width: 75%; display: table-cell;" class="filter">
      <p><br></p>

      <input type="button" class="collapsible" value="Power System">
      <div class="content" style="display:block;">
         <p> &nbsp;</p>
        
            <h1> Generator 1 Capacity<a class="button" href="#popup_flight_travlDil1"><svg id="myBtn"xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
</svg></a></h1>

<div id="popup_flight_travlDil1" class="overlay_flight_traveldil">
	<div class="popup_flight_travlDil">
		<h2>Generator</h2>
		<a class="close_flight_travelDl" href="#">&times;</a>
		<div class="content_flightht_travel_dil" style="margin:0px; width;200px; display:flex; align-items: center; text-align:justify">
         <img src="images\generator.jpg" style = "width:100px; height:100px; margin-right:20px;">
			generators for AC or DC applications in Military, Marine, or Specialty Vehicle applications The generators supply power to electrical systems on board, electric drives and complete mobile energy systems as well as air conditioning systems.
      </div>
	</div>
</div>
          <select name= "ps1" id="ps1">
            <option value="Option Not Selected">Select an option</option>     
            <option value=4>4 KW</option>
            <option value=6.4>6.4 KW</option>
            <option value=8>8 KW</option>
            <option value=12>12 KW</option>
            <option value=20>20 KW</option>
         </select>
      
         <p> &nbsp; <br></p>
            <h1> Generator 2 Capacity<a class="button" href="#popup_flight_travlDil2"><svg id="myBtn"xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
</svg></a></h1>

<div id="popup_flight_travlDil2" class="overlay_flight_traveldil">
	<div class="popup_flight_travlDil">
		<h2>Generator</h2>
		<a class="close_flight_travelDl" href="#">&times;</a>
		<div class="content_flightht_travel_dil" style="margin:0px; width;200px; display:flex; align-items: center; text-align:justify">
         <img src="images\generator.jpg" style = "width:100px; height:100px; margin-right:20px;">
			generators for AC or DC applications in Military, Marine, or Specialty Vehicle applications The generators supply power to electrical systems on board, electric drives and complete mobile energy systems as well as air conditioning systems.
      </div>
	</div>
</div>
          <select name="ps2" id="ps2">
            <option value="Option Not Selected">Select an option</option>     
            <option value=4>4 KW</option>
            <option value=6.4>6.4 KW</option>
            <option value=8>8 KW</option>
            <option value=12>12 KW</option>
            <option value=20>20 KW</option>
         </select>

         <p> &nbsp; <br></p>
            <h1> Battery System / UPS Capacity  <a class="button" href="#popup_flight_travlDil7"><svg id="myBtn"xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
</svg></a></h1>

<div id="popup_flight_travlDil7" class="overlay_flight_traveldil">
	<div class="popup_flight_travlDil">
		<h2>Battery System / UPS Capacity</h2>
		<a class="close_flight_travelDl" href="#">&times;</a>
		<div class="content_flightht_travel_dil" style="margin:0px; width;200px; display:flex; align-items: center; text-align:justify">
         <img src="images\ups.jpg" style = "width:100px; height:370px; width:200px; margin-right:20px;">
			An uninterruptible power supply or uninterruptible power source (UPS) is an electrical apparatus that provides emergency power to a load when the input power source or mains power fails. A UPS differs from an auxiliary or emergency power system or standby generator in that it will provide near-instantaneous protection from input power interruptions, by supplying energy stored in batteries, supercapacitors, or flywheels. The on-battery run-time of most uninterruptible power sources is relatively short (only a few minutes) but sufficient to start a standby power source or properly shut down the protected equipment. It is a type of continual power system.
      </div>
	</div>
</div>
          <select name="ps3" id="ps3">
               <option value="Option Not Selected">Select an option</option>     
               <option value=3>3 KW</option>
               <option value=6>6 KW</option>
               <option value=9>9 KW</option>
               <option value=12>12 KW</option>
               <option value=15>15 KW</option>
               <option value=18>18 KW</option>
         </select>

         <p> &nbsp; <br></p>
            <h1> Generator Redundancy / Synchronization<a class="button" href="#popup_flight_travlDil3"><svg id="myBtn"xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
</svg></a></h1>

<div id="popup_flight_travlDil3" class="overlay_flight_traveldil">
	<div class="popup_flight_travlDil">
		<h2>Redundancy</h2>
		<a class="close_flight_travelDl" href="#">&times;</a>
		<div class="content_flightht_travel_dil" style="margin:0px; width;200px; display:flex; align-items: center; text-align:justify">
			 The inclusion of extra components which are not strictly necessary to functioning, in case of failure in other components.<br>
      </div>
          <h2>Synchronization</h2>
         In an alternating current electric power system, synchronization is the process of matching the frequency of a generator or other source to a running network. An AC generator cannot deliver power to an electrical grid unless it is running at the same frequency as the network. If two unconnected segments of a grid are to be connected to each other, they cannot exchange AC power until they are brought back into exact synchronization.
	</div>
</div>
            <h5 style="font-size: 22px;">
               <input type="radio" name="ps4" value="Redundancy">  Generator Redundancy  <br>
               <input type="radio" name="ps4" value="Synchronization">  Generator Synchronization <br>
               <input type="radio" name="ps4"  value="None" checked>  None</h5>

         <p> &nbsp;</p> 
      </div>

   <p> &nbsp;</p> 
   
      <input type="button" class="collapsible" value="HVAC System">
      <div class="content" style="display:block;">
         <p> &nbsp;</p>
         
            <h1> Air-conditioning System 1 Capacity<a class="button" href="#popup_flight_travlDil4"><svg id="myBtn"xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
</svg></a></h1>

<div id="popup_flight_travlDil4" class="overlay_flight_traveldil">
	<div class="popup_flight_travlDil">
		<h2>Air-conditioning System</h2>
		<a class="close_flight_travelDl" href="#">&times;</a>
		<div class="content_flightht_travel_dil" style="margin:0px; width;200px; display:flex; align-items: center; text-align:justify">
         <img src="images\aircondition.jpg" style = "width:100px; height:100px; margin-right:20px;">
			These air conditioners are designed to meet climatic, technical, power, vibration, and transport requirements. Our equipment is designed to operate in humid climatic conditions and can withstand temperatures up to +40°C.
      </div>
	</div>
</div>
            <select name="hvacone" id="hvacone">
               <option value="Option Not Selected">Select an option</option>     
               <option value=12>12 KW</option>
               <option value=18>18 KW</option>
               <option value=24>24 KW</option>
               <option value=36>36 KW</option>
               <option value=43>43 KW</option>
            </select>
         <p> &nbsp; <br></p>
            <h1> Air-conditioning System 2 Capacity<a class="button" href="#popup_flight_travlDil4"><svg id="myBtn"xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
</svg></a></h1>

<div id="popup_flight_travlDil4" class="overlay_flight_traveldil">
	<div class="popup_flight_travlDil">
		<h2>Air-conditioning System</h2>
		<a class="close_flight_travelDl" href="#">&times;</a>
		<div class="content_flightht_travel_dil" style="margin:0px; width;200px; display:flex; align-items: center; text-align:justify">
         <img src="images\aircondition.jpg" style = "width:100px; height:100px; margin-right:20px;">
			These air conditioners are designed to meet climatic, technical, power, vibration, and transport requirements. Our equipment is designed to operate in humid climatic conditions and can withstand temperatures up to +40°C.
      </div>
	</div>
</div>
          <select name="hvactwo" id="hvactwo">
            <option value="Option Not Selected">Select an option</option>     
            <option value=12>12 KW</option>
            <option value=18>18 KW</option>
            <option value=24>24 KW</option>
            <option value=36>36 KW</option>
            <option value=43>43 KW</option>
         </select>
         <p> &nbsp; <br></p>
            <h1> Ventilation System Capacity<a class="button" href="#popup_flight_travlDil5"><svg id="myBtn"xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
</svg></a></h1>

<div id="popup_flight_travlDil5" class="overlay_flight_traveldil">
	<div class="popup_flight_travlDil">
		<h2>Ventilation Fans</h2>
		<a class="close_flight_travelDl" href="#">&times;</a>
		<div class="content_flightht_travel_dil" style="margin:0px; width;200px; display:flex; align-items: center; text-align:justify">
         <img src="images\ventilationfan.jpg" style = "width:100px; height:100px; margin-right:20px;">
			The truly space-saving axial fans are used to exchange hot and cold air in all sorts of devices and systems. Their outstanding features include a shallow installation depth, low noise level, and excellent efficiency.
      </div>
	</div>
</div>
         <select name="hvacthree" id="hvacthree">
            <option value="Option Not Selected">Select an option</option>     
            <option value=400>400 CFM</option>
            <option value=600>600 CFM</option>
            <option value=800>800 CFM</option>
            <option value=1000>1000 CFM</option>
         </select>
         <p> &nbsp; <br></p>
            <h1> Air-conditioning System Redundancy<a class="button" href="#popup_flight_travlDil6"><svg id="myBtn"xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
</svg></a></h1>

<div id="popup_flight_travlDil6" class="overlay_flight_traveldil">
	<div class="popup_flight_travlDil">
		<h2>Redundancy</h2>
		<a class="close_flight_travelDl" href="#">&times;</a>
		<div class="content_flightht_travel_dil" style="margin:0px; width;200px; display:flex; align-items: center; text-align:justify">
			 The inclusion of extra components which are not strictly necessary to functioning, in case of failure in other components.<br>
      </div>
   </div>
</div>
            <h5 style="font-size: 20px;">
                  <input type="radio" name="hvacfour" value="Yes"> Yes  <br>
                  <input type="radio" name="hvacfour" value="No" checked> No</h5>
               
         <p> &nbsp;</p>
            <h1> Ventilation System Redundancy<a class="button" href="#popup_flight_travlDil6"><svg id="myBtn"xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
</svg></a></h1>

<div id="popup_flight_travlDil6" class="overlay_flight_traveldil">
	<div class="popup_flight_travlDil">
		<h2>Redundancy</h2>
		<a class="close_flight_travelDl" href="#">&times;</a>
		<div class="content_flightht_travel_dil" style="margin:0px; width;200px; display:flex; align-items: center; text-align:justify">
			 The inclusion of extra components which are not strictly necessary to functioning, in case of failure in other components.<br>
      </div>
   </div>
</div>
            <h5 style="font-size: 20px;">
                  <input type="radio" name="hvacfive" value="Yes"> Yes  <br>
                  <input type="radio" name="hvacfive" value="No" checked> No</h5>
               
         <p> &nbsp;</p>
                  
               
      </div>
   <p> &nbsp;</p> 
      <input type="button" class="collapsible" value="Utility Features and Functionalities">
      <div class="content" style="display:block;">

         <p> &nbsp;</p>
            <h1> Telescopic Mast System Quantity<a class="button" href="#popup_flight_travlDil8"><svg id="myBtn"xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
</svg></a></h1>

<div id="popup_flight_travlDil8" class="overlay_flight_traveldil">
	<div class="popup_flight_travlDil">
		<h2>Telescopic Mast</h2>
		<a class="close_flight_travelDl" href="#">&times;</a>
		<div class="content_flightht_travel_dil" style="margin:0px; width;200px; display:flex; align-items: center; text-align:justify">
         <img src="images\telescopicmast.jpg" style = "width:100px; height:170px; width:160px; margin-right:20px;">
			Telescoping masts are ideal for deployment of transmission or surveillance equipment. Available in both Standard Duty and Heavy-Duty models, these masts offer a light weight elevation solution with a high payload capacity. These lightweight and reliable masts provide precise directional azimuth with full-length keyways and can be trailer or vehicle mounted.
      </div>
	</div>
</div>
               <select name="UFF1" id="UFF1">
                  <option value="Option Not Selected">Select an option</option>     
                  <option value=1>1</option>
                  
               </select>

         <p> &nbsp; <br></p>
            <h1> Telescopic Mast System Height<a class="button" href="#popup_flight_travlDil8"><svg id="myBtn"xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-info-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"/>
  <path d="m8.93 6.588-2.29.287-.082.38.45.083c.294.07.352.176.288.469l-.738 3.468c-.194.897.105 1.319.808 1.319.545 0 1.178-.252 1.465-.598l.088-.416c-.2.176-.492.246-.686.246-.275 0-.375-.193-.304-.533L8.93 6.588zM9 4.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
</svg></a></h1>

<div id="popup_flight_travlDil8" class="overlay_flight_traveldil">
	<div class="popup_flight_travlDil">
		<h2>Telescopic Mast</h2>
		<a class="close_flight_travelDl" href="#">&times;</a>
		<div class="content_flightht_travel_dil" style="margin:0px; width;200px; display:flex; align-items: center; text-align:justify">
         <img src="images\telescopicmast.jpg" style = "width:100px; height:170px; width:160px; margin-right:20px;">
			Telescoping masts are ideal for deployment of transmission or surveillance equipment. Available in both Standard Duty and Heavy-Duty models, these masts offer a light weight elevation solution with a high payload capacity. These lightweight and reliable masts provide precise directional azimuth with full-length keyways and can be trailer or vehicle mounted.
      </div>
	</div>
</div>
               <select name="UFF2" id="UFF2">
                  <option value="Option Not Selected">Select an option</option>     
                  <option value=2>2m</option>
                  <option value=4>4m</option>
                  <option value=8>8m</option>
                  <option value=12>12m</option>
                  <option value=15>15m</option>
                  <option value=18>18m</option>
               </select>

         <p> &nbsp; <br></p>
            <h1> Utilities and Infrastructure Monitoring and Control</h1>
            <h5 style="font-size: 20px;">
                  <input type="radio" name="UFF3" value="Yes"> Yes  <br>
                  <input type="radio" name="UFF3" value="No" checked> No</h5>

         <p> &nbsp;</p>
            <h1> Blinker Lights Availability</h1>
            <h5 style="font-size: 20px;">
                  <input type="radio" name="UFF4" value="Yes"> Yes  <br>
                  <input type="radio" name="UFF4" value="No" checked> No</h5>

         <p> &nbsp;</p>
            <h1> Work Light Availability</h1>
            <h5 style="font-size: 20px;">
                  <input type="radio" name="UFF5" value="Yes"> Yes  <br>
                  <input type="radio" name="UFF5" value="No" checked> No</h5>
               
         <p> &nbsp;</p>          
      </div>

   <p> &nbsp;</p> 
      <input type="button" class="collapsible" value="Onboard Systems Features and Functionalities">
      <div class="content" style="display:block;">
         <p> &nbsp;</p>
         
            
            <h1> Visualization System Availability</h1>
            <h5 style="font-size: 20px;">
                  <input type="radio" name="OSFF1" value="Yes"> Yes  <br>
                  <input type="radio" name="OSFF1" value="No" checked> No</h5>
               
         <p> &nbsp;</p>
            <h1> Surveillance System Availability</h1>
            <h5 style="font-size: 20px;">
                  <input type="radio" name="OSFF2" value="Yes"> Yes  <br>
                  <input type="radio" name="OSFF2" value="No" checked> No</h5>
               
         <p> &nbsp;</p>
            <h1> Communications Network System Availability</h1>
            <h5 style="font-size: 20px;">
                  <input type="radio" name="OSFF3" value="Yes"> Yes  <br>
                  <input type="radio" name="OSFF3" value="No" checked> No</h5>
               
         <p> &nbsp;</p>
               
      </div>
     
   <p> &nbsp;</p> 
      <input type="button" class="collapsible" value="Furniture Module">
      <div class="content">
         <p> &nbsp;</p>
         
            <h1> Console Availability</h1>
          <select name="F1" id="F1">
            <option value=100>Select an option</option>
            <option value=0>0 Module</option>     
            <option value=1>1 Module</option>
            <option value=2>2 Module</option>
            <option value=3>3 Module</option>
            <option value=4>4 Module</option>
            <option value=5>5 Module</option>
            <option value=6>6 Module</option>
            <option value=7>7 Module</option>
            <option value=8>8 Module</option>
            <option value=9>9 Module</option>
            <option value=10>10 Module</option>
            <option value=11>11 Module</option>
            <option value=12>12 Module</option>
         </select>
         <p> &nbsp; <br></p>
            <h1> 19" Equipment Rack Availability</h1>
          <select name="F2" id="F2" disabled>
            <option value=100>Select an option</option>
            <option value=0>0 Module</option>     
            <option value=1>1 Module</option>
            <option value=2>2 Module</option>
            <option value=3>3 Module</option>
            <option value=4>4 Module</option>
            <option value=5>5 Module</option>
            <option value=6>6 Module</option>
            <option value=7>7 Module</option>
            <option value=8>8 Module</option>
            <option value=9>9 Module</option>
            <option value=10>10 Module</option>
            <option value=11>11 Module</option>
            <option value=12>12 Module</option>
         </select>
         <p> &nbsp; <br></p>

            <h1> Storage Space Availability</h1>
          <select name="F3" id="F3" disabled>
            <option value=100>Select an option</option>
            <option value=0>0 Module</option>     
            <option value=1>1 Module</option>
            <option value=2>2 Module</option>
            <option value=3>3 Module</option>
            <option value=4>4 Module</option>
            <option value=5>5 Module</option>
            <option value=6>6 Module</option>
            <option value=7>7 Module</option>
            <option value=8>8 Module</option>
            <option value=9>9 Module</option>
            <option value=10>10 Module</option>
            <option value=11>11 Module</option>
            <option value=12>12 Module</option>
         </select>
         <p> &nbsp; <br></p>
               
      </div>
      <div id="overweight" style="margin-top:10px; margin-left:100px;"></div>
      <div id="overcost" style="margin-top:10px; margin-left:100px;"></div>
      
      <div class="footer">
         <br><br>
            <div class="nav-links" id="navLinks">
         <ul>
            <li><a href="model.php" ><button type="button" style="margin-left: 87px ;font-size: 24px; width: 200px;">Back to Models</button></a>
            <input type="submit" id ="advance" value="Advance to summary" style="margin-left: 510px; width: 200px; font-size: 24px;"> <br><br></li>
         </ul>
         </div>
      </form>
   
      <p> <br><br><br></p>
   </div>
      </div>

<div style="display: table-cell;" class="filter"> 
   <p><br></p>
   <div style="width: 100%; display: table-cell;" class="column1">
                     <?php 
                     $sql = "SELECT * FROM vehical where button = 'features12.php' ";
                     $result = $conn->query($sql);

                     if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        echo '<div style="width: 100%; display: table;" class="main" >';
                        echo '<div style="width: 100%; display: table-cell;" class="column1">';?>
                        <div class="swiper">
                            <!-- Additional required wrapper -->
                            <div class="swiper-wrapper">
                              <!-- Slides -->
                              <?php 
                      if ($row["image3"] == NULL){
                      echo '<div class="swiper-slide"><img src='.$row["image"].' alt="cat" height="190px" width= 100%> <br></div>';
                      echo '<div class="swiper-slide"><img src='.$row["image2"].' alt="cat" height="190px" width= 100%> <br></div>';
                     }
                     
                     else{
                      echo '<div class="swiper-slide"><img src='.$row["image"].' alt="cat" height="190px" width= 100%> <br></div>';
                      echo '<div class="swiper-slide"><img src='.$row["image2"].' alt="cat" height="190px" width= 100%> <br></div>';
                      echo '<div class="swiper-slide"><img src='.$row["image3"].' alt="cat" height="190px" width= 100%> <br></div>';
                     }
                     ?>
                              
                            </div>
                            <!-- If we need pagination -->
                            <div class="swiper-pagination"></div>

                            <!-- If we need navigation buttons -->
                            <div class="swiper-button-prev"></div>
                            <div class="swiper-button-next"></div>
                        </div>


                     <?php echo ' <h1 style="color: #000000;"> &nbsp;&nbsp; '. $row["name"] .'</h1> ';
                     echo'<p>
                        <ul type="square">
                           <li>'; echo $row["minpax"]."-".$row["maxpax"]." Pax"; echo '</li>
                           <li>'; echo $row["operation"]." Operation".'</li>
                           <li>'; echo $row["terrain"]." Terrain".'</li>
                           <li>'; echo $row["cabin"]." Cabin ".'</li>
                           <li>'; echo "Available Module Hardpoints : ".$row["hardpoints"].'</li>
                           <li id="hard">'; echo "Remaining Module Hardpoints : <span class='hardpoints'> ".$row["hardpoints"].'</span></li>
                           <li style="display:none">'; echo "<span class='hardpointshidden' >".$row["hardpoints"].'</span></li>
                           <li id="weight">'; echo "Available Weight Capacity : <span class='weight'> ".$row["weight"].' Kg</span></li>
                           <li style="display:none">'; echo "<span class='weighthidden' >".$row["weight"].'</span></li>
                           <li id="cost">'; echo "Total Cost : <span class='cost'>$".$row["cost"].' </span></li>
                           <li style="display:none">'; echo "<span class='costhidden' >".$row["cost"].'</span></li>
                        </ul>
                     </p>
                     <br>
                     <br>
                  </div>';
                      echo '<div style="display: table-cell;"></div>';

                     }

                     ?>
</div>
</div>
</div>
      <script>
      var coll = document.getElementsByClassName("collapsible");
      var i;

      for (i = 0; i < coll.length; i++) {
        coll[i].addEventListener("click", function() {
          this.classList.toggle("active");
          var content = this.nextElementSibling;
          if (content.style.maxHeight){
            content.style.maxHeight = null;
          } else {
            content.style.maxHeight = content.scrollHeight + "px";
          } 
        });
      }
      </script>
      
   </section>
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
   <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"> </script>
   <script type="text/javascript" src="scroll.js"></script>
   <script>
      $(document).ready(function() {
      $('#aForm').on("submit", function(){
        var ehidden = document.getElementsByClassName('weight')[0].innerHTML;
        $(this).append("<input type='hidden' name='myname1' id='myname1' value=' " + ehidden + " '/>");
        var ehidden2 = document.getElementsByClassName('hardpoints')[0].innerHTML;
        $(this).append("<input type='hidden' name='myname2' id='myname2' value=' " + ehidden2 + " '/>");
        var ehidden3 = document.getElementsByClassName('cost')[0].innerHTML;
        $(this).append("<input type='hidden' name='myname3' id='myname3' value=' " + ehidden3 + " '/>");
      });
      $('#overweight').text("");
      $('form').on('change', 'input, select, textarea', function(){
         var generator_capacity = {"Option Not Selected":0, 4:150, 6.4:225, 8:325, 12:450, 20:750};
         var battery_system = {"Option Not Selected":0, 3:30, 6:60, 9:90, 12:120, 15:150, 18:180};
         var air_capacity = {"Option Not Selected":0, 12:50, 18:75, 24:150, 36:200, 43:300};
         var ventilation = {"Option Not Selected":0, 100:5, 200:10, 300:15, 400:20, 500:25, 600:30, 800: 40, 1000:50};
         var air_redundancy = {"Yes":25, "No":0}
         var ventilation_redundancy = {"Yes":5, "No":0}
         var telescopic_heigth = {"Option Not Selected":0, 2:60, 4:80, 8:150, 12:200, 15:225, 18:250};
         var Utilities_Infrastructure = {"Yes":50, "No":0}; /* change yes value for baseline 6 and above*/
         var Blinker_Work = {"Yes":10, "No":0};  /* change yes value for baseline 6 and above*/
         var Visualization_surveillance_communication ={"Yes":100, "No":0} /* change yes value for baseline 6 and above*/
         var console_equiptment = {0:0, 100:0, 1:75, 2:150, 3:225, 4:300, 5:375, 6:450, 7:525, 8:600, 9:675, 10:750, 11:825, 12:900};
         var storage_space ={0:0, 100:0, 1:50, 2:100, 3:150, 4:200, 5:250, 6:300, 7:350, 8:400, 9:450, 10:500}
         var redundancy_synchronization = {"Redundancy":25, "Synchronization":50, "None":0};

         var generator_capacity_cost = {"Option Not Selected":0, 4:20000, 6.4:27000, 8:34000, 12:41000, 20:48000};
         var battery_system_cost = {"Option Not Selected":0, 3:3000, 6:6000, 9:9000, 12:12000, 15:15000, 18:18000};
         var air_capacity_cost = {"Option Not Selected":0, 12:6000, 18:9000, 24:12000, 36:18000, 43:21500};
         var ventilation_cost = {"Option Not Selected":0, 100:250, 200:500, 300:700, 400:1000, 500:1250, 600:1500, 800: 2000, 1000:2500};
         var air_redundancy_cost = {"Yes":5000, "No":0}
         var ventilation_redundancy_cost = {"Yes":250, "No":0}
         var telescopic_heigth_cost = {"Option Not Selected":0, 2:3000, 4:6000, 8:12000, 12:18000, 15:22500, 18:24000};
         var Utilities_Infrastructure_cost = {"Yes":35000, "No":0}; 
         var Blinker_Work_cost = {"Yes":4500, "No":0};  
         var Work_Light_cost = {"Yes":2000, "No":0};
         var Visualization_cost ={"Yes":70000, "No":0} 
         var surveillance_cost = {"Yes":60000, "No":0}
         var communication_cost ={"Yes":40000, "No":0}
         var console_equiptment_cost = {0:0, 100:0, 1:4000, 2:8000, 3:12000, 4:16000, 5:20000, 6:24000, 7:28000, 8:32000, 9:36000, 10:40000, 11:44000, 12:48000};
         var equiptment_cost = {0:0, 100:0, 1:3000, 2:6000, 3:9000, 4:12000, 5:15000, 6:18000, 7:21000, 8:24000, 9:27000, 10:30000};
         var storage_space_cost ={0:0, 100:0, 1:2500, 2:5000, 3:7500, 4:10000, 5:12500, 6:15000, 7:17500, 8:20000, 9:22500, 10:25000}
         var redundancy_synchronization_cost = {"Redundancy":5000, "Synchronization":15000, "None":0};
         
         var c1 = generator_capacity_cost[$("#ps1").val()];
         var c2 = generator_capacity_cost[$("#ps2").val()];
         var c3 = battery_system_cost[$("#ps3").val()];
         var c4 = redundancy_synchronization_cost[$('input[name="ps4"]:checked').val()];
         var c5 = air_capacity_cost[$("#hvacone").val()];
         var c6 = air_capacity_cost[$("#hvactwo").val()];
         var c7 = ventilation_cost[$("#hvacthree").val()];
         var c8 = air_redundancy_cost[$('input[name="hvacfour"]:checked').val()];
         var c9 = ventilation_redundancy_cost[$('input[name="hvacfive"]:checked').val()];
         var c11 = telescopic_heigth_cost[$("#UFF2").val()];
         var c12 = Utilities_Infrastructure_cost[$('input[name="UFF3"]:checked').val()];
         var c13 = Blinker_Work_cost[$('input[name="UFF4"]:checked').val()];
         var c14 = Work_Light_cost[$('input[name="UFF5"]:checked').val()];
         var c15 = Visualization_cost[$('input[name="OSFF1"]:checked').val()];
         var c16 = surveillance_cost[$('input[name="OSFF2"]:checked').val()];
         var c17 = communication_cost[$('input[name="OSFF3"]:checked').val()];
         var c18 = console_equiptment_cost[$("#F1").val()];
         var c19 = equiptment_cost[$("#F2").val()];
         var c20 = storage_space_cost[$("#F3").val()];

         var s1 = generator_capacity[$("#ps1").val()];
         var s2 = generator_capacity[$("#ps2").val()];
         var s3 = battery_system[$("#ps3").val()];
         var s4 = redundancy_synchronization[$('input[name="ps4"]:checked').val()];
         var s5 = air_capacity[$("#hvacone").val()];
         var s6 = air_capacity[$("#hvactwo").val()];
         var s7 = ventilation[$("#hvacthree").val()];
         var s8 = air_redundancy[$('input[name="hvacfour"]:checked').val()];
         var s9 = ventilation_redundancy[$('input[name="hvacfive"]:checked').val()];
         var s11 = telescopic_heigth[$("#UFF2").val()];
         var s12 = Utilities_Infrastructure[$('input[name="UFF3"]:checked').val()];
         var s13 = Blinker_Work[$('input[name="UFF4"]:checked').val()];
         var s14 = Blinker_Work[$('input[name="UFF5"]:checked').val()];
         var s15 = Visualization_surveillance_communication[$('input[name="OSFF1"]:checked').val()];
         var s16 = Visualization_surveillance_communication[$('input[name="OSFF2"]:checked').val()];
         var s17 = Visualization_surveillance_communication[$('input[name="OSFF3"]:checked').val()];
         var s18 = console_equiptment[$("#F1").val()];
         var s19 = console_equiptment[$("#F2").val()];
         var s20 = storage_space[$("#F3").val()];
        
         var total =s1+s2+s3+s4+s5+s6+s7+s8+s9+s11+s12+s13+s14+s15+s16+s17+s18+s19+s20;    
         console.log(total);
         var e = document.getElementsByClassName('weight')[0];
         var ehidden = document.getElementsByClassName('weighthidden')[0].innerHTML;
         var newvalue = parseInt(ehidden) - parseInt(total);
         e.innerHTML = newvalue + ' KG';
         var hid = document.getElementsByClassName('hardpoints')[0].innerHTML;
         
         var total_cost =c1+c2+c3+c4+c5+c6+c7+c8+c9+c11+c12+c13+c14+c15+c16+c17+c18+c19+c20;    
         console.log(total_cost);
         var e_cost = document.getElementsByClassName('cost')[0];
         var ehidden_cost = document.getElementsByClassName('costhidden')[0].innerHTML;
         var newvalue_cost = parseInt(total_cost)+parseInt(ehidden_cost);
         e_cost.innerHTML = "$"+newvalue_cost;
         var hid = document.getElementsByClassName('hardpoints')[0].innerHTML;

         $('#hidden1').text(hid);
         $('#hidden2').text(newvalue + ' KG');
         if (total<ehidden){
            $('#overweight').text("").css('color','black');
            $('.weight').css('color','black');
         }
         else {
            $('#overweight').text("*Weight limit has over-reached please reselect some of the options to procced to summary page!!").css('color','red');
            $('.weight').css('color','red');
         }
         if (total>ehidden){
            $('#advance').prop('disabled', true).css('background-color','#FFFFFF');
         }
         else{
            $('#advance').prop('disabled', false).css('background-color','#EBECF0');
         }

      });
      });
   </script>
</body>
</html>