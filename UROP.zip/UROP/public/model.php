	<?php 
	include('header.php'); // imports the code from header.php
	include('db.php'); // imports the code from db.php to connect to database for data
	?>

	<style>
		/* style for the slidable images on model's page */
		.swiper {
			width: 335px;
			height: 220px;
		}

		.swiper-slide img{
			width: 100%;
			height: 190px;
		}

		.swiper-pagination{
			    background: rgb(255,255,255,0.64);
			    bottom: 0px;
		}
	</style>
	
	<section class="configurator">
		<br><br>
		<h1 class="up" style="margin-left: 102px "> Choose your model </h1>
		<h1 class="down" style="margin-left: 105px "> The information you provide will help us to find the right vehicle model for you </h1>
		<br><br>
		<hr width=100%> 
		<br>
	</section>

	<section>
		<!-- the 3 div helps create 3 columns with equal width for baseline cards and a column to select the sepcifications/filter property -->
	    <div style="width: 100%; display: table;" class="choose">
	        <div style="display: table-row; height: 100px;">
	            <div style="width: 30%; display: table-cell;" class="filter">
	                <h1 style="margin-left: 10px "> Filter</h1> 
	                <br>
	                <p> Number of pax </p>
	                <br>
	                <form method="POST" action='<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>' class="switch">
	                	<input type="range" value="0" min="0" max="20" name="passanger" oninput="this.nextElementSibling.value = this.value" > <!-- slider to select how many passanger capacity it can hold-->
						<output>0</output>
	                <br><br> 
	                <hr width="75%">

	                <br>
	                <p> Type of operation </p>
	                <br>
	                <form method="POST" action='<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>' class="switch">
	  					<input type="radio" name="operation" value="Mobile" > Mobile <br> <!-- button to select type of operations -->
	  					<input type="radio" name="operation" value="Static"> Static
	                <br> <br>
	                <hr width="75%">

	                <br>
	                <p> Type of terrain </p>
	                <br> 
	                <form method="POST" action='<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>' class="switch">
	                	<input type="radio" name="terrain" value="urban" > Urban <br> <!-- button to select type of terrain -->
	  					<input type="radio" name="terrain" value="rural"> Rural
	                <br><br> 
	                <hr width="75%">

	                <br>
	                <p> Type of cabin </p>
	                <br> 
	                <form method="POST" action='<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>' class="switch">
	  					<input type="radio" name="cabin" value="Expandable" > Expandable <br>
	  					<input type="radio" name="cabin" value="Non-expandable" > non-expandable <br><br> <!-- button to select type of cabin -->


	  					<input type="submit" class="submit" value="Apply Filters" style="margin-left: 10px; font-size: 23px; padding-top: 5px; padding-right: 5px; padding-bottom: 5px; padding-left: 5px; border-radius: 5px;"> <!-- submits forms to apply the fetaures selected so that it displays based on what is selected -->
	  					<a href="model.php"><button style="margin-left: 10px; padding-top: 5px; padding-left: 5px; padding-right: 5px; padding-bottom:5px; border-radius: 5px; "><h1 style="font-size: 23px; font-family: Bebas Neue; color: #000000;">Reset Filter</h1></button></a><br><!-- it resets all the features and displays all baselines -->
	  				</form></form></form></form>
	                <br><br> 
	            </div>

	            <div style="display: table-cell;" class="filter"> 
	                <h1 style="margin-left: 3px "> vehicle model match your search criteria </h1>
	                <br><br>
	                
	                <?php
	                echo "<h2 style='text-align: left;'>The filters chosen are as follows :</h2><br>";
	                $pa = NULL;
	                $op = NULL;
	                $te = Null;
	                $ca = Null; 
					if ($_SERVER["REQUEST_METHOD"] == "POST") {
					    if (isset($_POST['passanger'])) {
					    	$pa=htmlspecialchars($_REQUEST['passanger']);
					    	if ($pa > 0){
					    		echo '<h3>Number of pax : ' .$pa.'</h3></br>'; // displays number of pax selected in the filter only if greater than 0
					    	}  
					    } 
					    else {
					    	$pa = NULL;  
					    }
					}

					if ($_SERVER["REQUEST_METHOD"] == "POST") {
					    if (isset($_POST['operation'])) {
					    	$op=htmlspecialchars($_REQUEST['operation']);
					        echo '<h3>Type of operation : ' .$op.'</h3></br>'; // displays type of operation selected in the filter 
					    } 
					    else {
					    	$op = Null;
					    }
					}

	                if ($_SERVER["REQUEST_METHOD"] == "POST") {
					    if (isset($_POST['terrain'])) {
					    	$te=htmlspecialchars($_REQUEST['terrain']);
					        echo '<h3>Type of terrain : ' .$te.'</h3></br>'; // displays type of terrain selected in the filter 
					    } 
					    else {
					    	$te = NULL;
					    }
					}

	                if ($_SERVER["REQUEST_METHOD"] == "POST") {
					    if (isset($_POST['cabin'])) {
					    	$ca=htmlspecialchars($_REQUEST['cabin']);
					        echo '<h3>Type of cabin : ' .$ca.'</h3></br>';  // displays type of cabin selected in the filter 
					    } 
					    else {
					    	$ca = NULL;
					    }
					}     

					// all the if, elseif and else statements helps to search through the database based on the features that user have selecetd 
					if ($op == NULL & $pa == Null & $te==Null & $ca==null){
						$sql = "SELECT * FROM vehical";
					}
					elseif($op == Null & $pa < 2 & $te == Null & $ca == Null){
						$sql = "SELECT * FROM vehical";
					}
					elseif($op == Null & $pa != Null & $te==Null & $ca==null){
						$sql = "SELECT * FROM vehical where minpax<='$pa'and maxpax >='$pa'";
					}
					elseif($op != Null & $pa < 2 & $te==Null & $ca==null){
						$sql = "SELECT * FROM vehical where operation= '$op'";
					}
					elseif($op == Null & $pa < 2 & $te!=Null & $ca==null){
						$sql = "SELECT * FROM vehical where terrain= '$te'";
					}
					elseif($op == Null & $ca < 2 & $te==Null & $ca!=null){
						$sql = "SELECT * FROM vehical where cabin='$ca'";
					}
					elseif($op != Null & $pa < 2 & $te!=Null & $ca==null){
						$sql = "SELECT * FROM vehical where operation= '$op' and terrain= '$te'";
					}
					elseif($op != Null & $pa < 2 & $te==Null & $ca!=null){
						$sql = "SELECT * FROM vehical where operation= '$op' and cabin='$ca'";
					}
					elseif($op == Null & $pa < 2 & $te!=Null & $ca!=null){
						$sql = "SELECT * FROM vehical where terrain= '$te' and cabin='$ca'";
					}
					elseif($op != Null & $pa < 2 & $te!=Null & $ca!=null){
						$sql = "SELECT * FROM vehical where operation= '$op' and cabin='$ca' and terrain='$te'";
					}
					elseif($op != Null & $pa >= 2 & $te==Null & $ca==null){
						$sql = "SELECT * FROM vehical where operation= '$op' and minpax<='$pa'and maxpax >='$pa'";
					}
					elseif($op == Null & $pa >= 2 & $te!=Null & $ca==null){
						$sql = "SELECT * FROM vehical where terrain= '$te' and minpax<='$pa'and maxpax >='$pa'";
					}
					elseif($op == Null & $ca >= 2 & $te==Null & $ca!=null){
						$sql = "SELECT * FROM vehical where cabin='$ca' and minpax<='$pa'and maxpax >='$pa'";
					}
					elseif($op != Null & $pa >= 2 & $te!=Null & $ca==null){
						$sql = "SELECT * FROM vehical where operation= '$op' and terrain= '$te' and minpax<='$pa'and maxpax >='$pa'";
					}
					elseif($op != Null & $pa >= 2 & $te==Null & $ca!=null){
						$sql = "SELECT * FROM vehical where operation= '$op' and cabin='$ca' and minpax<='$pa'and maxpax >='$pa'";
					}
					elseif($op == Null & $pa >= 2 & $te!=Null & $ca!=null){
						$sql = "SELECT * FROM vehical where terrain= '$te' and cabin='$ca' and minpax<='$pa'and maxpax >='$pa'";
					}
					elseif($op != Null & $pa >= 2 & $te!=Null & $ca!=null){
						$sql = "SELECT * FROM vehical where operation= '$op' and cabin='$ca' and terrain='$te' and minpax<='$pa'and maxpax >='$pa'";
					}
					else{
						$sql = "SELECT * FROM vehical where operation= '$op' and terrain= '$te' and cabin='$ca' and minpax<='$pa'and maxpax >='$pa'";
					}
	                
					$result = $conn->query($sql); // the reslut of the above queries get stored in the variable result 
					$loop = 0; 
					if ($result->num_rows > 0) {
					  while($row = $result->fetch_assoc()) {
					  	if ($loop % 3 == 0) {
			  	     		echo '<div style="width: 120%; display: table;" class="main" >'; // while loop runs through the desierd baselines sorted by filters 
                			echo '<div style="width: 26%; display: table-cell;" class="column1">'; // if statement helps to order the baseline cards such that if it belongs to left, middle or the right column
                	?>
						
						<div class="swiper">
						  <!-- Additional required wrapper -->
						  <div class="swiper-wrapper">
						    <!-- Slides -->
						    <?php 
						    if ($row["image3"] == NULL){
						    echo '<div class="swiper-slide"><img src='.$row["image"].' alt="cat" height="190px" width= 100%> <br></div>'; // the baseline images get displayed
						    echo '<div class="swiper-slide"><img src='.$row["image2"].' alt="cat" height="190px" width= 100%> <br></div>';
							// if more images needs to be added then first add the path of the image to database then copy paste the above line and change the column name of image2 to whatever you named in your database
						  	}
						  	else{
						    echo '<div class="swiper-slide"><img src='.$row["image"].' alt="cat" height="190px" width= 100%> <br></div>';
						    echo '<div class="swiper-slide"><img src='.$row["image2"].' alt="cat" height="190px" width= 100%> <br></div>';
						    echo '<div class="swiper-slide"><img src='.$row["image3"].' alt="cat" height="190px" width= 100%> <br></div>';
						  	}
							// this code supports only 3 images in the swipe feature if more needs to be added then add column in database and add elseif statement and follow if and else statement structure
						  	?>
						    
						  </div>
						  <!-- If we need pagination -->
						  <div class="swiper-pagination"></div>

						  <!-- If we need navigation buttons -->
						  <div class="swiper-button-prev"></div>
						  <div class="swiper-button-next"></div>
						</div>			

						<?php 
						echo ' <h1 style="color: #000000;"> &nbsp;&nbsp; '. $row["name"] .'</h1> '; // gets other data from the database and displays on card under the image
							echo'<p>
								<ul type="square"> 
									<li>'; echo $row["minpax"]."-".$row["maxpax"]." Pax"; echo '</li> 
									<li>'; echo $row["operation"]." Operation".'</li>
									<li>'; echo $row["terrain"]." Terrain".'</li>
									<li>'; echo $row["cabin"]." Cabin ".'</li>
								</ul>
							</p>
							<a href='.$row["button"].'><button>configure</button></a>
							<br><br><br>
						</div>
						&nbsp;&nbsp;'; // <a href> tag helps user to select that particular baseline, and then go to next web page select other fetaures
		                echo '<div style="display: table-cell;"></div>';
						$loop += 1;}

						// similar structure as a if statement
						elseif ($loop % 3 == 1) {
							echo '<div style="width: 120%; display: table;" class="main" >';
		                	echo '<div style="width: 30%; display: table-cell;" class="column1">';
							?>
							<div class="swiper">
						 	 <!-- Additional required wrapper -->
						  	<div class="swiper-wrapper">
						     <!-- Slides -->
						    <?php 
						    if ($row["image3"] == NULL){
						    echo '<div class="swiper-slide"><img src='.$row["image"].' alt="cat" height="190px" width= 100%> <br></div>';
						    echo '<div class="swiper-slide"><img src='.$row["image2"].' alt="cat" height="190px" width= 100%> <br></div>';
						  	}
						
						  	else{
						    echo '<div class="swiper-slide"><img src='.$row["image"].' alt="cat" height="190px" width= 100%> <br></div>';
						    echo '<div class="swiper-slide"><img src='.$row["image2"].' alt="cat" height="190px" width= 100%> <br></div>';
						    echo '<div class="swiper-slide"><img src='.$row["image3"].' alt="cat" height="190px" width= 100%> <br></div>';
						  	}
						  	?>
						    
						  </div>
						  <!-- If we need pagination -->
						  <div class="swiper-pagination"></div>

						  <!-- If we need navigation buttons -->
						  <div class="swiper-button-prev"></div>
						  <div class="swiper-button-next"></div>
						</div>		
							<?php
							echo ' <h1 style="color: #000000;"> &nbsp;&nbsp;'. $row["name"] .'</h1> ';
							echo'<p>
								<ul type="square">
									<li>'; echo $row["minpax"]."-".$row["maxpax"]." Pax"; echo '</li>
									<li>'; echo $row["operation"]." Operation".'</li>
									<li>'; echo $row["terrain"]." Terrain".'</li>
									<li>'; echo $row["cabin"]." Cabin ".'</li>
								</ul>
							</p>
							<a href='.$row["button"].'><button>configure</button></a>
							<br>
							<br>
							<br>
						</div>
						&nbsp;&nbsp;';
						echo '<div style="display: table-cell;" > </div>';
						$loop += 1;}

						// similar structure as if statement
						elseif ($loop % 3 == 2) {
							echo ' 
                    		<div style="width: 120%; display: table;" class="main" > 
                        	<div style="width: 36%; display: table-cell;" class="column1">
                       		 '?>
                            <div class="swiper">
						  	<!-- Additional required wrapper -->
						  	<div class="swiper-wrapper">
						    <!-- Slides -->
						    <?php 
						    if ($row["image3"] == NULL){
						    echo '<div class="swiper-slide"><img src='.$row["image"].' alt="cat" height="190px" width= 100%> <br></div>';
						    echo '<div class="swiper-slide"><img src='.$row["image2"].' alt="cat" height="190px" width= 100%> <br></div>';
						  	}
						  	
						  	else{
						    echo '<div class="swiper-slide"><img src='.$row["image"].' alt="cat" height="190px" width= 100%> <br></div>';
						    echo '<div class="swiper-slide"><img src='.$row["image2"].' alt="cat" height="190px" width= 100%> <br></div>';
						    echo '<div class="swiper-slide"><img src='.$row["image3"].' alt="cat" height="190px" width= 100%> <br></div>';
						  	}
						  	?>
						    
						  </div>
						  <!-- If we need pagination -->
						  <div class="swiper-pagination"></div>

						  <!-- If we need navigation buttons -->
						  <div class="swiper-button-prev"></div>
						  <div class="swiper-button-next"></div>
						</div>		
                            <?php echo ' <h1 style="color: #000000;"> &nbsp;&nbsp;'. $row["name"] .'</h1> ';
							echo'<p>
								<ul type="square">
									<li>'; echo $row["minpax"]."-".$row["maxpax"]." Pax"; echo '</li>
									<li>'; echo $row["operation"]." Operation".'</li>
									<li>'; echo $row["terrain"]." Terrain".'</li>
									<li>'; echo $row["cabin"]." Cabin ".'</li>
								</ul>
							</p>
							<a href='.$row["button"].'><button>configure</button></a>
							<br>
							<br>
							<br>
						</div>
						<h1 style="margin-left: 30px"> </h1>';
						echo '<div style=" display: table-cell;" >&nbsp; </div>
						</div></div></div>
                    	<div style="width: 100%; display: table;" class="main" >
                        <br>
                    </div>';
						$loop += 1;} 
				}
			}

					else {
					  echo "0 results"; // if user selects specifications such that no baseline with those features then returns 0 results 
					}
	                
					?>
					</div>
					<div style="width: 100%; display: table;" class="main" >
						<br><br><br><br>
					</div>
	            </div>	
	        </div>
	    </div>
	</section>

	<!-- used for swiper images -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"> </script>
	<script type="text/javascript">
		jQuery(document).ready(function(){
			const swiper = new Swiper('.swiper', {
  // Optional parameters
  direction: 'horizontal',
  loop: true,

  // If we need pagination
  pagination: {
    el: '.swiper-pagination',
  },

  // Navigation arrows
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },

  // And if we need scrollbar
  scrollbar: {
    el: '.swiper-scrollbar',
  },
});
})
	</script>

</body>
</html>



	