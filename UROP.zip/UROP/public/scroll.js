      jQuery(document).ready(function(){
         const swiper = new Swiper('.swiper', {
           // Optional parameters
           direction: 'horizontal',
           loop: true,

           // If we need pagination
           pagination: {
             el: '.swiper-pagination',
           },

           // Navigation arrows
           navigation: {
             nextEl: '.swiper-button-next',
             prevEl: '.swiper-button-prev',
           },

           // And if we need scrollbar
           scrollbar: {
             el: '.swiper-scrollbar',
           },
         });

         $('input[name="ps4"]').click(function(){
            var genvalue = $(this).val();
            if(genvalue == "Synchronization" || genvalue == "Redundancy"){
               var capacityone = $('#ps1').val();
               $('#ps2').val(capacityone);
               $('#ps2').attr('disabled','disabled');
               selectedgenerator();
            }
            else{
               $('#ps2').removeAttr('disabled');
         }})
            function selectedgenerator(){
              $('#ps1').change(function(){
                  var capacityone = $(this).val();
                  $('#ps2').val(capacityone);
               })
         }

         $('input[name="hvacfour"]').click(function(){
            var genvalue2 = $(this).val();
            if(genvalue2 == "Yes"){
               var hvacone = $('#hvacone').val();
               $('#hvactwo').val(hvacone);
               $('#hvactwo').attr('disabled','disabled');
               selectedgenerator2();
            }
            else{
               $('#hvactwo').removeAttr('disabled');
         }})
            function selectedgenerator2(){
              $('#hvacone').change(function(){
                  var hvacone = $(this).val();
                  $('#hvactwo').val(hvacone);
               })
         }
          
         $('#F1').change(function(){
            var hardpoint1 = $('#F1').val();
            if (hardpoint1 == 100){
               $("#F2").val(100).change();
               $("#F3").val(100).change();
               $('#F2').attr('disabled','disabled');
               $('#F3').attr('disabled','disabled');
            }
            else {
               var ehidden = document.getElementsByClassName('hardpointshidden')[0].innerHTML;
               var value = parseInt(ehidden) - parseInt(hardpoint1);
               var options2 = document.forms['aForm']['F2'].options;
               $("#F2").val(100).change();
               $("#F3").val(100).change();
               $('#F2').removeAttr('disabled');
               $('#F3').attr('disabled','disabled');
               for (let i=0; i<(ehidden+1); i++){
                  if (i>(value)){
                     options2[i+1].disabled = true;
               }
                  else{
                     options2[i+1].disabled = false;
                  }
               }
            }
            changer();
            
         })
         $('#F2').change(function(){
            var hardpoint1 = $('#F1').val();
            var hardpoint2 = $('#F2').val();
            if (hardpoint2 == 100){
               $("#F3").val(100).change();
               $('#F3').attr('disabled','disabled');
            }
            else {
            var ehidden = document.getElementsByClassName('hardpointshidden')[0].innerHTML;
            var value = parseInt(ehidden) - parseInt(hardpoint1)- parseInt(hardpoint2);
            var options3 = document.forms['aForm']['F3'].options;
            $("#F3").val(100).change();
            $('#F3').removeAttr('disabled');
            for (let i=0; i<(ehidden+1); i++){
               if (i>(value)){
                  options3[i+1].disabled = true;
            }
               else{
                  options3[i+1].disabled = false;
            }
         }
      }
            changer();
            
         })
         $('#F3').change(function(){
            changer();

         })
         function changer(){
            var hardpoint1 = $('#F1').val();
            var hardpoint2 = $('#F2').val();
            var hardpoint3 = $('#F3').val();
            var e = document.getElementsByClassName('hardpoints')[0];
            var ehidden = document.getElementsByClassName('hardpointshidden')[0];
            if (hardpoint1==100){
               var hardpoint1=0;
            }
            if (hardpoint2==100){
               var hardpoint2=0;
            }
            if (hardpoint3==100){
               var hardpoint3=0;
            }
            var newvalue = parseInt(ehidden.innerHTML) - parseInt(hardpoint1)- parseInt(hardpoint2)- parseInt(hardpoint3);
            e.innerHTML = newvalue;
         }
      })
