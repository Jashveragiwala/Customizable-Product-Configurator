<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="with=device-width,
	initial-scale=1.0">
	<title> ST Engineering </title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css"/>
   <link rel="stylesheet" href="style.css">
	<style>

	*{
	margin: 0;
	padding: 0;
	font-family: 'Bebas Neue', cursive;
	}

	.dropdown h1{
		font-size: 25px;
		color: #000000;
	}

	.dropdown button{
		font-size: 22px;
	}

	.contact-col form{
	width: 63%;
	padding-left: 120px;
	}

	.swiper {
      width: 335px;
      height: 220px;
   }

   .swiper-slide img{
      width: 100%;
      height: 190px;
   }

   .swiper-pagination{
      background: rgb(255,255,255,0.64);
      bottom: 0px;       
   }

</style>
</head>
<body>
	<?php 
	session_start(); 
    include('db.php');
   ?>
	<section class="homepage-nav-bar">
		<br>
		<nav> 
			<div class="nav-links logo-wrapper" id="navLinks">
				<ul>
					<li> <h1> Truck configurator </h1> </li>
					<li> <a href="https://www.stengg.com/"><img src="images/logo.jpg" width=100px align="right"></a></li>
				</ul>
			</div>
		</nav>
		<hr align="center"; width = 100% >
	</section>

	<section>
		<nav> 
			<div class="nav-links" id="navLinks">
				<ul>
					<li><a href="index.php">Start</a></li> 
					<li><a href="model.php">Model</a></li> 
					<li><a href="features5.php">Features</a></li>
					<li><a href="summary5.php">Summary</a></li>
				</ul>
			</div>
		</nav>
	</section>

	<section class="configurator">
		<br>		
		<br>
		<h1 class="up"> &nbsp;&nbsp;&nbsp;YOUR IDEAL TRUCK </h1>
		<h1 class="down"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;View the summary of your configuration here </h1>
		<br>
		<br>
		<hr width=100%> 
		<br>
	</section>

	<section class="dropdown">
	    <div style="width: 100%; display: table;" class="choose">
	        <div style="display: table-row;">
	            <div style="width: 75%; display: table-cell;" class="filter">
		<p><br></p>
		
			<h1 style='margin-left: 105px; font-size: 35px;'> Power System </h1><br>
			<?php 
			if($_POST["ps1"]=="Option Not Selected"){
				$ps1 = $_POST["ps1"];
			}
			else {
				$ps1 = $_POST["ps1"].' KW';
			}
			if($_POST["ps4"]=="None"){
				$ps4 = "None";
				if($_POST["ps2"]=="Option Not Selected"){
					$ps2 = $_POST["ps2"];
				}
				else {
					$ps2 = $_POST["ps2"].' KW';
				}
			}
			else {
				$ps4 ="Generator ".$_POST["ps4"];
				if($_POST["ps1"]=="Option Not Selected"){
					$ps2 = $_POST["ps1"];
				}
				else {
					$ps2 = $_POST["ps1"].' KW';
				}
			}
			if($_POST["ps3"]=="Option Not Selected"){
				$ps3 = $_POST["ps3"];
			}
			else {
				$ps3 = $_POST["ps3"].' KW';
			}?>
			<h1 style='margin-left: 105px; color: #808080;'>Generator 1 Capacity : <?php echo $ps1; ?></h1><br>
			<h1 style='margin-left: 105px; color: #808080;'>Generator 2 Capacity : <?php echo $ps2; ?></h1><br>
			<h1 style='margin-left: 105px; color: #808080;'>Battery System / UPS Capacity : <?php echo $ps3; ?></h1><br>
			
			<h1 style='margin-left: 105px; color: #808080;'>Generator Redundancy / Synchronization : <?php echo $ps4; ?></h1><br><br>
			
			<?php 
			if($_POST["hvacone"]=="Option Not Selected"){
				$hvacone = $_POST["hvacone"];
			}
			else {
				$hvacone = $_POST["hvacone"].' KW';
			}
			if($_POST["hvacfour"]=="No"){
				if($_POST["hvactwo"]=="Option Not Selected"){
					$hvactwo = $_POST["hvactwo"];
				}
				else {
					$hvactwo = $_POST["hvactwo"].' KW';
				}
			}
			else {
				$hvactwo = $hvacone;
			}
			if($_POST["hvacthree"]=="Option Not Selected"){
				$hvacthree = $_POST["hvacthree"];
			}
			else {
				$hvacthree = $_POST["hvacthree"].' CFM';
			}
			?>
			<h1 style='margin-left: 105px; font-size: 35px;'> HVAC System </h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> Air-conditioning System 1 Capacity : <?php echo $hvacone; ?></h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> Air-conditioning System 2 Capacity : <?php echo $hvactwo; ?></h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> Ventilation System Capacity : <?php echo $hvacthree; ?></h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> Air-conditioning System Redundancy : <?php echo $_POST["hvacfour"]; ?></h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> Ventilation System Redundancy : <?php echo $_POST["hvacfive"]; ?></h1><br><br>

			<?php
			if($_POST["UFF2"]=="Option Not Selected"){
				$UFF2 = $_POST["UFF2"];
			}
			else {
				$UFF2 = $_POST["UFF2"].' m';
			}
			?>
			<h1 style='margin-left: 105px; font-size: 35px;'> Utility Features and Functionalities </h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> Telescopic Mast System Quantity : <?php echo $_POST["UFF1"]; ?></h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> Telescopic Mast System Height : <?php echo $UFF2; ?></h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> Utilities and Infrastructure Monitoring and Control : <?php echo $_POST["UFF3"]; ?></h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> Blinker Lights Availability : <?php echo $_POST["UFF4"]; ?></h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> Work Light Availability : <?php echo $_POST["UFF5"]; ?></h1><br><br>


			<h1 style='margin-left: 105px; font-size: 35px;'> Onboard Systems Features and Functionalities </h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> Visualization System Availability : <?php echo $_POST["OSFF1"]; ?></h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> Surveillance System Availability : <?php echo $_POST["OSFF2"]; ?></h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> Communications Network System Availability : <?php echo $_POST["OSFF3"]; ?></h1><br><br>

			<h1 style='margin-left: 105px; font-size: 35px;'> Furniture </h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> Console Availability : <?php if ($_POST["F1"] == 100 || empty($_POST['F1'])){
					$F1 = "Option Not Selected";
					echo "Option Not Selected";
				} 
				else {
					$F1 = $_POST["F1"]." Module";
					echo $_POST["F1"]." Module"; 
				}?></h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> 19' Equipment Rack Availability : <?php if (empty($_POST['F2']) || $_POST["F2"] == 100){
					$F2 = "Option Not Selected";
					echo "Option Not Selected";
				} 
				else {
					$F2 = $_POST["F2"]." Module";
					echo $_POST["F2"]." Module"; 
				} ?> </h1><br>
			<h1 style='margin-left: 105px; color: #808080;'> Storage Space Availability : <?php if (empty($_POST['F3']) || $_POST["F3"] == 100){
					$F3 = "Option Not Selected";
					echo "Option Not Selected";
				} 
				else {
					$F3 = $_POST["F3"]." Module";
					echo $_POST["F3"]." Module"; 
				} ?></h1><br><br>

	</div>


<div style="display: table-cell;" class="filter"> 
	<p><br></p>
	<div style="width: 100%; display: table-cell;" class="column1">
							<?php 
                     $sql = "SELECT * FROM vehical where button = 'features5.php' ";
                     $result = $conn->query($sql);

                     if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc();
                        echo '<div style="width: 100%; display: table;" class="main" >';
                      	echo '<div style="width: 100%; display: table-cell;" class="column1">';?>
	                    <div class="swiper">
	                          <!-- Additional required wrapper -->
	                          <div class="swiper-wrapper">
	                            <!-- Slides -->
	                            <?php 
						    if ($row["image3"] == NULL){
						    echo '<div class="swiper-slide"><img src='.$row["image"].' alt="cat" height="190px" width= 100%> <br></div>';
						    echo '<div class="swiper-slide"><img src='.$row["image2"].' alt="cat" height="190px" width= 100%> <br></div>';
						  	}
						  	
						  	else{
						    echo '<div class="swiper-slide"><img src='.$row["image"].' alt="cat" height="190px" width= 100%> <br></div>';
						    echo '<div class="swiper-slide"><img src='.$row["image2"].' alt="cat" height="190px" width= 100%> <br></div>';
						    echo '<div class="swiper-slide"><img src='.$row["image3"].' alt="cat" height="190px" width= 100%> <br></div>';
						  	}
						  	?>
	                            
	                          </div>
	                          <!-- If we need pagination -->
	                          <div class="swiper-pagination"></div>

	                          <!-- If we need navigation buttons -->
	                          <div class="swiper-button-prev"></div>
	                          <div class="swiper-button-next"></div>
	                    </div>
                     
                     <?php
                     echo ' <h1 style="color: #000000; font-size: 35px"> &nbsp;&nbsp; '. $row["name"] .'</h1> ';
                     echo'<p>
                        <ul type="square">
                           <li>'; echo $row["minpax"]."-".$row["maxpax"]." Pax"; echo '</li>
                           <li>'; echo $row["operation"]." Operation".'</li>
                           <li>'; echo $row["terrain"]." Terrain".'</li>
                           <li>'; echo $row["cabin"]." Cabin ".'</li>
						   <li>'; echo "Available Module Hardpoints : ".$row["hardpoints"].'</li>
                           <li id="hard">'; echo "Remaining Module Hardpoints : <span class='hardpoints'> ".$_POST["myname2"].'</span></li>
                           <li id="weight">'; echo "Available Weight Capacity : <span class='weight'> ".$_POST["myname1"].'</span></li>
						   <li id="cost">'; echo "Total Cost : <span class='cost'> ".$_POST["myname3"].'</span></li>
                        </ul>
                     </p>
                     <br>
                     <br>
                  </div>';
                      echo '<div style="display: table-cell;"></div>';
                     }?>
</div>
</div>
</div>
		<script>
		var coll = document.getElementsByClassName("collapsible");
		var i;

		for (i = 0; i < coll.length; i++) {
		  coll[i].addEventListener("click", function() {
		    this.classList.toggle("active");
		    var content = this.nextElementSibling;
		    if (content.style.maxHeight){
		      content.style.maxHeight = null;
		    } else {
		      content.style.maxHeight = content.scrollHeight + "px";
		    } 
		  });
		}
		</script>
	</section>

	<section class="summary">
		<div class="contact-col">
				 <form action='try3.php' method="POST">
				 	<input type="text" name="name" placeholder="Enter Your Name" required></input>
				 	<input type="email" name ="email" placeholder="Enter Email Address" required></input>
				 	<input type="tel" name ="number" placeholder="Enter Phone Number" required></input>
				 	<input type="hidden" name="post" value="Baseline1"></input>
					<input type="hidden" name="opt1" value=<?php echo $ps1;?>></input>
					<input type="hidden" name="opt2" value=<?php echo $ps2;?>></input>
					<input type="hidden" name="opt3" value=<?php echo $ps3;?>></input>
					<input type="hidden" name="opt4" value=<?php echo $_POST["ps4"];?>></input>
					<input type="hidden" name="opt6" value=<?php echo $hvacone;?>></input>
					<input type="hidden" name="opt7" value=<?php echo $hvactwo;?>></input>
					<input type="hidden" name="opt8" value=<?php echo $hvacthree;?>></input>
					<input type="hidden" name="opt9" value=<?php echo $_POST["hvacfour"];?>></input>
					<input type="hidden" name="opt10" value=<?php echo $_POST["hvacfive"];?>></input>
					<input type="hidden" name="opt11" value=<?php echo $_POST["UFF1"];?>></input>
					<input type="hidden" name="opt12" value=<?php echo $UFF2;?>></input>
					<input type="hidden" name="opt13" value=<?php echo $_POST["UFF3"];?>></input>
					<input type="hidden" name="opt14" value=<?php echo $_POST["UFF4"];?>></input>
					<input type="hidden" name="opt15" value=<?php echo $_POST["UFF5"];?>></input>
					<input type="hidden" name="opt16" value=<?php echo $_POST["OSFF1"];?>></input>
					<input type="hidden" name="opt17" value=<?php echo $_POST["OSFF2"];?>></input>
					<input type="hidden" name="opt18" value=<?php echo $_POST["OSFF3"];?>></input>
					<input type="hidden" name="opt19" value=<?php echo $F1;?>></input>
					<input type="hidden" name="opt20" value=<?php echo $F2;?>></input>
					<input type="hidden" name="opt21" value=<?php echo $F3;?>></input>
					<input type="hidden" name="post22" value="features5.php"></input>
					<input type="hidden" name="post23" value="summary5.php"></input>
				 	<br><br>
				 	
				 	<ul>
		            <li style="list-style: none; display:  inline-block; position:  relative; text-align: left; font-size: 24px; color:  #696969;">
		            	<a href="features5.php" ><button type="button" style="padding-left: 5px; padding-right: 5px; padding-top: 5px; padding-bottom: 5px; border-radius: 10px; width: 200px; margin-right: 552px;">Back to features</button></a>
		            <button type="submit" style="padding-left: 5px; padding-right: 5px;padding-top: 5px; padding-bottom: 5px; border-radius: 10px; width: 200px;">Send for Quotation</button>
		         	</li>
		         </ul>
				 </form>
			</div>
		
	</section>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"> </script>
    <script type="text/javascript">
      jQuery(document).ready(function(){
         const swiper = new Swiper('.swiper', {
  // Optional parameters
  direction: 'horizontal',
  loop: true,

  // If we need pagination
  pagination: {
    el: '.swiper-pagination',
  },

  // Navigation arrows
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },

  // And if we need scrollbar
  scrollbar: {
    el: '.swiper-scrollbar',
  },
});
      })
   </script>

</body>
</html>