<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="with=device-width,
	initial-scale=1.0">
	<title> ST Engineering </title>
	<link rel="stylesheet" href="style.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
	<section class="homepage-nav-bar">
		<br>
		<nav> 
			<div class="nav-links logo-wrapper" id="navLinks">
				<ul>
					<li> <h1 class="logo-name"> Truck configurator  </h1> </li> <!-- these are clickable links to go to different links-->
					<li> <a href="https://www.stengg.com/"><img src="images/logo.jpg" width=100px align="right"></a></li> <!--for the logo-clickable link of st-engineering on top right hand side -->
				</ul>
			</div>
		</nav>
		<hr align="center"; width = 100% >
		<br>
	</section>
	<section>
		<nav> 
			<div class="nav-links" id="navLinks">
				<ul>
					<li><a href="index.php">Start</a></li> <!-- these are clickable links to go to different links-->
					<li><a href="model.php">Model</a></li> <!-- these are clickable links to go to different links-->
					<li><a href="features.php">Features</a></li> <!-- these are clickable links to go to different links-->
					<li><a href="summary.php">Summary</a></li> <!-- these are clickable links to go to different links-->
				</ul>
			</div>
		</nav>
	</section>
</body>
</html>